Pizzaro - Food Online Ordering WooCommerce Theme

The theme's documentation and the customer support are provided online. Here are a few useful links on getting started with the theme.

1. Theme Documentation - https://transvelo.github.io/docs/pizzaro/
2. Support - https://themeforest.net/item/pizzaro-food-online-ordering-woocommerce-theme/19209143/support/
3. Getting Started with WooCommerce - https://docs.woothemes.com/documentation/plugins/woocommerce/getting-started/
4. Getting Started with Wordpress - https://codex.wordpress.org/Getting_Started_with_WordPress
5. Installing Pizzaro - https://www.youtube.com/watch?v=PNxfITw833s

You can use any of the icons listed here : https://transvelo.github.io/pizzaro/pizzaro-icons/ or http://fontawesome.io/icons/ 

If the icons you want is not listed here you can generate your own custom icons from IcoMoon : https://icomoon.io/ or Fontastic : http://fontastic.me/ or any other icon generator website. Once you've generated your custom icons, you will have to add them to your website. We have explained the process here : https://www.youtube.com/watch?v=hkCO2fWT7Sg